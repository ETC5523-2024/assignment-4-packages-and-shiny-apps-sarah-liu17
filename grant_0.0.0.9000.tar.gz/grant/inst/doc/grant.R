## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message = FALSE, warning = FALSE----------------------------------
library(grant)
library(ggplot2)
library(dplyr)

## ----eval = FALSE, echo=TRUE--------------------------------------------------
#  # Install the remotes package if you haven't already
#  install.packages("remotes")

## ----eval = FALSE, echo=TRUE--------------------------------------------------
#  # Install the grant package from GitHub
#  remotes::install_github("ETC5523-2024/assignment-4-packages-and-shiny-apps-sarah-liu17", subdir = "grant")

## -----------------------------------------------------------------------------
library(grant)

## ----eval=FALSE, echo=TRUE----------------------------------------------------
#  run_grant_app()

## -----------------------------------------------------------------------------
summarize_grants_by_category(grant_opp)

